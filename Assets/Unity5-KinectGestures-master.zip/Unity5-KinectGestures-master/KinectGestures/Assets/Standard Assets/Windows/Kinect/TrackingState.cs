using RootSystem = System;
using System.Linq;
using System.Collections.Generic;
namespace Windows.Kinect
{
    //
    // Windows.Kinect.TrackingState
    //
    public enum TrackingState : int
    {
        NotTracked                               =0,
        Inferred                                 =1,
        Tracked                                  =2,
    }

}

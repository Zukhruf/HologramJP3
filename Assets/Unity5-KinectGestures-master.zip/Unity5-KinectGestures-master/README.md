# Unity5-KinectGestures
How to build Kinect v2 Gestures in your Unity 5 game

### Before you Begin
If you want to get start working with the kinect, follow the instructions in this link:
http://bit.ly/Unity-Kinect


This project builds off the Microsoft plugin examples as well as Carmine Si's examples:
<ul>
<li> http://go.microsoft.com/fwlink/?LinkID=513177 - Microsoft Kinect Unity Plugin</li>
<li> https://github.com/carmines/workshop/tree/master/Unity </li>
</ul>

I added step by step instructions and explination about how and why the code works and how to modify for your needs. 

If you have questions about it tweet me [@KatVHarris](http://twitter.com/katvharris)

